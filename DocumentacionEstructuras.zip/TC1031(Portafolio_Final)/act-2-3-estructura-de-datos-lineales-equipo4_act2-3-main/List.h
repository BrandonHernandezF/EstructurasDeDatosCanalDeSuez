#include <iostream>
#include <string>
#include <string.h>
#include <sstream>

#ifndef LIST_H
#define LIST_H

using namespace std;

// =================================================================
// Definition of the Node class
// =================================================================

template <class T>
class List;

template <class T>
class Barco
{
private:
	Barco();
	Barco(int _dia, int _mes, int _year, int _hora, int _minuto, char _mar, string,  Barco *_next);
  Barco(T _registro, Barco<T> *head);
  Barco(T _registro);
  T getData();
  Barco<T> *getNext();
  void setData(T data);
  void setNext(Barco<T> *next);
  

	int dia, mes, year, hora, minuto;
	char mar;
  string id;
  T data;
  Barco<T> *next;
  Barco<T> *head;
  

	friend class List<T>;
};

// =================================================================
// Constructor. Initializes the data of the node. The variable next
// is initialized to nullptr.
//
// @param val, stored data in the node.
// =================================================================
template <class T>
Barco<T>::Barco()
{
}

template <class T>
Barco<T>::Barco(T _registro)
{
  data = _registro;
}

template <class T>
Barco<T>::Barco(T data, Barco<T> *next){
    this->data = data;
    this->next = next;
}

template <class T>
Barco<T>::Barco(int _dia, int _mes, int _year, int _hora, int _minuto, char _mar, string _id,  Barco *_next)
{
  dia = _dia;
  mes = _mes;
  year = _year;
  hora = _hora;
  minuto = _minuto;
  mar = _mar;
  id = _id;
  next = _next;
}
// =================================================================
// Constructor. Initializes both instance variables.
//
// @param val, stored data in the node.
// @param nxt, the next node.
// =================================================================

template <class T>
T Barco<T>::getData(){
    return data;
}

template <class T>
Barco<T> *Barco<T>::getNext(){
    return next;
}

template <class T>
void Barco<T>::setData(T data){
    this->data = data;
}

template <class T>
void Barco<T>::setNext(Barco<T> *next){
    this->next = next;
}
// =================================================================
// Definition of the List class
// =================================================================

template <class T>
class List
{
private:
	Barco<T> *head;
	int size;

public:
	List();
	~List();


	void create(int _dia, int _mes, int _year, int _hora, int _minuto, char _mar, string);
	void read();	
	void clear();
  int getSize();
  void getMeses(string, string, int);
  Barco<T> getHead();
  void clear(int);
  int length() const;
  bool empty() const;
  void getAllMeses(string _pref);
  void ordenamiento();
  bool change(int pos1, int pos2);
  void addLast(T data);
  void addFirst(T data);
  void find(string _prefijo);
  
  //void reposition(Barco *NewIndex, int index);

};

// =================================================================
// Constructor. Initializes both instance variables to zero.
// =================================================================

template <class T>
List<T>::List() : head(nullptr), size(0)
{
}

// =================================================================
// Destructor. Removes all items from the list.
// =================================================================
template <class T>
List<T>::~List()
{
	clear();
}

// =================================================================
// Adds an element at the start of the linked list. The element that
// was at the begining is shifted to the right.
//
// Worst case complexity: O(1)
// =================================================================
template <class T>
void List<T>::create(int _dia, int _mes, int _year, int _hora, int _minuto, char _mar, string _id)
{
	head = new Barco<T>(_dia, _mes, _year, _hora, _minuto, _mar, _id, head);
  size++;
}

// =================================================================
// Adds an element in index (0 <= index <= size). The element that
// was in that position is shifted to the right.
//
// Worst case complexity: O(n)
// =================================================================
template <class T>
void List<T>::addLast(T data){
    if (size == 0){ //(head->getNext() == nullptr) 
        addFirst(data);
    }
    else{
        Barco<T> *curr = head;
        while(curr->getNext() != nullptr){
            curr = curr->getNext();
        }
        curr->setNext(new Barco<T>(data));
        size++;
    }
}

// =================================================================
// Adds an element at the start of the linked list. The element that
// was at the begining is shifted to the right.
//
// Worst case complexity: O(1)
// =================================================================
template <class T>
void List<T>::addFirst(T data){
    head = new Barco<T>(data, head);
    size++;
}

// =================================================================
// Returns the position of an item in the list.
//
// @returns the position of an item in the list, -1 otherwise.
//
// Worst case complexity: O(n)
// =================================================================
  template <class T>
  void List<T>::read()
  {
    Barco<T> *curr = head;
      for (int i=0; i<size ; i++){
      curr->getData().print();
      curr = curr->next;
      }

    
  }
// =================================================================
// Search for the prefix given on the list and display the Barco that
// contain the prefix.
//
// Worst case complexity: O(n)
// =================================================================
  template <class T>
  void List<T>::find(string _prefijo)
  {
    Barco<T> *curr = head;
    string prefijoComp;
      for (int i=0; i<size ; i++){
      prefijoComp = curr->getData().identificador1.substr(0,3);
      if (prefijoComp == _prefijo)
      {
      curr->getData().print();
      }
      curr = curr->next;
      }

    
  }

// =================================================================
// Removes all the items from the list.
//
// Worst case complexity: O(n)
// =================================================================
template <class T>
void List<T>::clear()
{
	Barco<T> *curr = head;
    while (curr != nullptr){
        head = head->next;
        delete curr;
        curr = head;
    }
    size = 0;
}

// =================================================================
// Returns the number of items in the list.
// O(1)
// @returns size, the number of items in the list.
// =================================================================
template <class T>
int List<T>::length() const
{
	return size;
}

// =================================================================
// Returns true if the list is empty or false if not.
//
// @returns true if the list is empty, false otherwise.
// O(1)
// =================================================================
template <class T>
bool List<T>::empty() const
{
	return (head == nullptr);
}

// =================================================================
// The linked list Barco is sorted using the method of exchange sort.
//
// Worst case complexity: O(n^2)
// =================================================================
template <class T>
void List<T>::ordenamiento() 
{ 
  Barco<T> *curr = head;
  Barco<T> *aux;
  Barco<T> *aux2;
  for (int i=0; i < size;i++)
  {
    //cout << size << endl;
    aux = curr;
    for (int j = i+1; j < size;j++)
    {
      if (curr->getData().year1 == aux->next->getData().year1)
      {
        if (curr->getData().mes1 == aux->next->getData().mes1)
        {
          if (curr->getData().dia1 == aux->next->getData().dia1)
          {
            if (curr->getData().horas == aux->next->getData().horas)
            {
              if (curr->getData().minutos >= aux->next->getData().minutos)
              {
                change(i,j);
              }
            }
          else if (curr->getData().horas > aux->next->getData().horas)
          {
            
            change(i,j);
          
          }
        }
        else if (curr->getData().dia1 > aux->next->getData().dia1)
        {
          change(i,j);
          
        }

      }
      
      else if (curr->getData().mes1 > aux->next->getData().mes1)
      { 
        change(i,j);
      }
      }

      else if (curr->getData().year1 > aux->next->getData().year1)
      {
        change(i,j);
      }
      aux = aux->next;
    }
    curr = curr->next;
  }

}

// =================================================================
// Deletes the Barco data of a certain index.
//
// Worst case complexity: O(n)
// =================================================================
template <class T>
void List<T>::clear(int index)
{
  T auxData;
  Barco<T> *curr = head;
  if (index == 0)
  {
    auxData = head->data;
    head = curr->next;
    delete curr;
    size--;

  }
  else if (size-1 == index)
  {
    Barco<T> *curr = head;
        while(curr->next->next != nullptr){
            curr = curr->next;
        }
        auxData = curr->next->data;
        
        delete curr->next;
        curr->next=nullptr;
        size--;
  }
 
	else if (size-1 > index)
	{
    for (int i=1; i<index; i++){
        curr = curr->next;
    }
    Barco<T> *aux;
    aux = curr->next;
    curr->next = curr->next->next;
    delete aux;
    auxData = curr->data;
    size--;
	}
}

// =================================================================
// Change the position of two datas.
//
// Worst case complexity: O(n)
// =================================================================
template <class T>
bool List<T>::change(int pos1, int pos2)
{
  if (pos1<0 || pos1>= size || pos2 < 0 || pos2 >=size)
  {
    return false;
  }
  if (pos1 == pos2)
  {
    return true;
  }
  int posMin = (pos1 < pos2) ? pos1 : pos2;
  int posMax = (pos1 > pos2) ? pos1 : pos2;

  Barco<T> *curr1 = head;

  for (int i=1; i <= posMin; i++)
  {
    curr1 = curr1->getNext();
  }

  Barco<T> *curr2 = curr1;
  for (int k=1; k<= (posMax - posMin); k++)
  {
    curr2 = curr2->getNext();
  }

  T dataAux = curr1->getData();
  curr1->setData(curr2->getData());
  curr2->setData(dataAux);
  return true;
}

// =================================================================
// Returns the number of items in the linked list.
//
// Worst case complexity: O(1)    
// =================================================================
template<class T>
int List<T>::getSize()
{
  return size;
}

// =================================================================
// Returns the first element (head) of the linked list.
//
// Worst case complexity: O(1)
// =================================================================
template<class T>
Barco<T> List<T>::getHead()
{
  return head;
}

// =================================================================
// Obtain the data in Barcos related to certain month.
//
// Worst case complexity: O(n)
// =================================================================
template<class T>
void List<T>::getMeses(string _pref, string _mes, int _mesNum )
{
  
  int contR = 0;
  int contM = 0;
  string IDR = "";
  string IDM = "";

  Barco<T> *curr = head;
  if (curr == nullptr)
  {
    
  }
  
  while (curr != nullptr)
  { 
    if( _pref == curr->getData().identificador1.substr(0,3))
    { 
      if (_mesNum == curr->getData().mes1)
      {
      if (curr->getData().mar == 'R')
      {
        contR++;
        IDR = IDR + curr->getData().identificador1 + " ";
      }
      else
      {
        contM++;
        IDM = IDM + curr->getData().identificador1 + " ";
      }

      }
      }
  
    curr = curr->getNext();
  } 
  if (contR>0 && contM ==0)
  {
    cout << _mes << "\nR " << contR << ": " << IDR << endl;
  }
  else if (contR==0 && contM>0)
  {
    cout << _mes << "\nM " << contM << ": " << IDM << endl;
  }
  else if (contR>0 && contM>0)
  {
    cout << _mes << "\nM " << contM << ": " << IDM << "\nR " << contR << ": " << IDR << endl;
  }
  else
  {

  }
  
}

// =================================================================
// Obtain the data of all months.
//
// Worst case complexity: O(1)
// =================================================================
template<class T>
void List<T>::getAllMeses(string prefijo)
{
  getMeses(prefijo,"jan", 1);
  getMeses(prefijo,"feb", 2);
  getMeses(prefijo,"mar", 3);
  getMeses(prefijo,"apr", 4);
  getMeses(prefijo,"may", 5);
  getMeses(prefijo,"jun", 6);
  getMeses(prefijo,"jul", 7);
  getMeses(prefijo,"aug", 8);
  getMeses(prefijo,"sep", 9);
  getMeses(prefijo,"oct", 10);
  getMeses(prefijo,"nov", 11);
  getMeses(prefijo,"dec", 12);
}

#endif /* LIST_H */