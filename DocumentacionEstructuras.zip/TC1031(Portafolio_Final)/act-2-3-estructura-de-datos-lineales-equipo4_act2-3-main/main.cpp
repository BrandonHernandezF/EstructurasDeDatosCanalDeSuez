// =========================================================
// File: main.cpp
// Authors: Brandon Alan Hernández Flores - A00830202, Gustavo Luna Muñoz - A01411619 , Kailin Wu - A00830574
// Date: 17/10/2021
// =========================================================

#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include "List.h"

using namespace std;

struct registrosb
{
  string cadena1, fecha1, identificador1, hora;
  int dia1, mes1, year1, horas, minutos;
  char mar, caracter1;

  void print()
  {
    cout << fecha1 << " " << hora << " " << mar << " " << identificador1 << endl;
  }
  
};

int turnMestoInt(string _Mes)
{
  if (_Mes == "jan")
  {
    return 1;
  }
  else if (_Mes == "feb")
  {
    return 2;
  }
  else if (_Mes == "mar")
  {
    return 3;
  }
  else if (_Mes == "abr")
  {
    return 4;
  }
  else if (_Mes == "may")
  {
    return 5;
  }
  else if (_Mes == "jun")
  {
    return 6;
  }
  else if (_Mes == "jul")
  {
    return 7;
  }
  else if (_Mes == "ago")
  {
    return 8;
  }
  else if (_Mes == "sep")
  {
    return 9;
  }
  else if (_Mes == "oct")
  {
    return 10;
  }
  else if (_Mes == "nov")
  {
    return 11;
  }
  else 
  {
    return 12;
  }
};


int main() {
  string cadena, fecha, hora, identificador, prefijo;
  char entrada;
  int nBarcos;
  registrosb reg;
  List<registrosb> Barcos;
    
  cin >> nBarcos >> prefijo;

  for (int i=0; i<nBarcos; i++)
  {
    //cout << "introduce la secuencia: ";//
      
    cin >> fecha >> hora>> entrada >> identificador;
    // 01-02-20 23:00 M 2HUCO1

    reg.hora = hora;
    reg.fecha1 = fecha;
    reg.dia1 = stoi(fecha.substr(0,2));
    reg.mes1 = stoi(fecha.substr(3,2));
    reg.year1 = stoi(fecha.substr(6,2));
    reg.horas = stoi(hora.substr(0,2));
    reg.minutos = stoi(hora.substr(3,2));
    reg.identificador1 = identificador;
    reg.mar = entrada;
    Barcos.addLast(reg);

  }
  /*cout << "//////////PRINT DE LOS INPUTS//////////" << endl;
  Barcos.read();*/
  Barcos.ordenamiento();
  /*
  cout << "//////////PRINT DE LOS INPUTS ORDENADOS//////////" << endl;
  Barcos.read();
  cout << "//////////PRINT DE LOS QUE TIENEN EL MISMO ID////////////" << endl;
  Barcos.find(prefijo);
  cout << endl;*/
  
  Barcos.getAllMeses(prefijo);

  return 0;
}