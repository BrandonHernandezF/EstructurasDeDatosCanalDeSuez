#include <iostream>
#include <string>
#ifndef BARCO_H
#define BARCO_H
#include "Fecha.h"
#include "Reloj.h"
#include "Identificador.h"

class Barco{
  public:

  Barco();
  Barco(int dia, int mes, int year, int hora, int minuto, char mar, string id);

  Fecha& getFecha();
  Reloj& getReloj();
  Identificador& getIdentificador();

  void impresion();
  
  private:

  Fecha fecha;
  Reloj reloj;
  Identificador id;

  
};

Barco::Barco()
{
  fecha.setDia(0);
  fecha.setMes(0);
  fecha.setYear(0);
  reloj.setHora(0);
  reloj.setMinuto(0);
  id.setMar('a');
  id.setID("0");
}

Barco::Barco(int _dia, int _mes, int _year, int _hora, int _minuto, char _mar, string _id)
{
  fecha.setDia(_dia);
  fecha.setMes(_mes);
  fecha.setYear(_year);
  reloj.setHora(_hora);
  reloj.setMinuto(_minuto);
  id.setMar(_mar);
  id.setID(_id);
}

void Barco::impresion()
{
  if (0<= fecha.getDia() && fecha.getDia() <10)
  {
    cout << "0" << fecha.getDia();
  }
  else
    {
        cout << fecha.getDia();
    }

    if (0<=fecha.getMes() && fecha.getMes() <10)
    {
        cout << "-" << "0" << fecha.getMes();
    }
    else 
    {
        cout << "-" << fecha.getMes();
    }
    cout << "-" << fecha.getYear();
    
  if (0<= reloj.getHora() && reloj.getHora() < 10)
  {
    cout << " 0" << reloj.getHora() << ":";

  }
  else 
  {
    cout << " " << reloj.getHora() << ":";
  }
  
  if ( 0 <= reloj.getMinuto() && reloj.getMinuto() < 10 ){
    cout << "0" << reloj.getMinuto();
  }
  else {
  cout << reloj.getMinuto();
  }
  cout << " " << id.getMar() << " " << id.getID() << endl;
}

Fecha& Barco::getFecha()
{
  return fecha;
}

Reloj& Barco::getReloj()
{
  return reloj;
}

Identificador& Barco::getIdentificador()
{
  return id;
}


#endif