// =================================================================
//
// File: main.cpp
// Authors: Brandon Alan Hernández Flores, Gustavo Luna Muñoz, Kailin Wu

// Date: 10/09/2021
//
// =================================================================
#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include "Fecha.h"
#include "Reloj.h"
#include "Identificador.h"
#include "Barco.h"

using namespace std;

void swapping(Barco *a, Barco *b)
{
  Barco v = *a;
  *a = *b;
  *b = v; 
}

void intercambio(Barco *Barcos[], int &nBarcos)
{ 
  for (int i=0; i < nBarcos;i++)
  {
    for (int j = i+1; j < nBarcos;j++)
    {

      if (Barcos[i]->getFecha().getYear() == Barcos[j]->getFecha().getYear())
      {
        if (Barcos[i]->getFecha().getMes() == Barcos[j]->getFecha().getMes())
        {
          if (Barcos[i]->getFecha().getDia() == Barcos[j]->getFecha().getDia())
          {
            if (Barcos[i]->getReloj().getHora() == Barcos[j]->getReloj().getHora())

            {
              if (Barcos[i]->getReloj().getMinuto() >= Barcos[j]->getReloj().getMinuto())
              {
                swapping(Barcos[i],Barcos[j]);
                
              }
          }
          else if (Barcos[i]->getReloj().getHora() > Barcos[j]->getReloj().getHora())
          {
            
            swapping(Barcos[i],Barcos[j]);
          
          }
        }
        else if (Barcos[i]->getFecha().getDia() > Barcos[j]->getFecha().getDia())
        {
          swapping(Barcos[i],Barcos[j]);
          
        }

      }
      
      else if (Barcos[i]->getFecha().getMes() > Barcos[j]->getFecha().getMes())
      { 
        swapping(Barcos[i],Barcos[j]); 
      }
      }

      else if (Barcos[i]->getFecha().getYear() > Barcos[j]->getFecha().getYear())
      {
        swapping(Barcos[i],Barcos[j]);
      }
    }

  }
}


int main() {
	string cadena, fecha, hora, identificador, prefijo;
    char entrada, caracter;
    int nBarcos;
    vector<string> aux(7);
    
    cin >> nBarcos >> prefijo;
    
    
    

    //string: "01-02-20 23:00 M 2HUCO1"
    
    Barco *Barcos[nBarcos];
    //Barcos = new Barco[nBarcos];

    Fecha* Fechas;
    Fechas = new Fecha[nBarcos];

    Reloj* Relojes;
    Relojes = new Reloj[nBarcos];

    Identificador* Ids;
    Ids = new Identificador[nBarcos];

    for (int i=0; i<nBarcos; i++){
    //cout << "introduce la secuencia: ";//
      
    cin >> fecha >> hora>> entrada >> identificador;
    
    
    
    //cout << fecha << hora << entrada << identificador;
    int contpos=0;
    int longitud = fecha.length();
    //cout << longitud << endl;

    for (int i = 0; i < longitud; i=i+3) 
    {
          aux[contpos++]= fecha.substr(i,2);
    }
    longitud = hora.length();

    for (int i=0; i<longitud; i=i+3)
    {
      aux[contpos++]=hora.substr(i,2);
    }

    Fechas[i] = Fecha(stoi(aux[0]),stoi(aux[1]),stoi(aux[2]));
    Relojes[i] = Reloj(stoi(aux[3]), stoi(aux[4]));
    

    Ids[i] = Identificador(entrada, identificador);

    Barcos[i] = new Barco(Fechas[i].getDia(), Fechas[i].getMes(), Fechas[i].getYear(), Relojes[i].getHora(), Relojes[i].getMinuto(), Ids[i].getMar(), Ids[i].getID());
    
    }

    intercambio(Barcos, nBarcos);
    
    //cout  << "\n//////////ORDENADO/////////////\n" << endl;//

    /*for (int i=0; i<nBarcos; i++)
    {
      Barcos[i]->impresion();
    }*/

  

    int caracteres = prefijo.size();
   // cout << caracteres;

    
    //cout << "\n///////CON IDENTIFICADOR///\n" << endl;//
    for (int i = 0; i < nBarcos; i++)
    {
      string clave = Barcos[i]->getIdentificador().getID().substr(0,prefijo.size());

      if (clave == prefijo)
      {
        Barcos[i]->impresion();
      }
    }






	return 0;
}
