#include <iostream>
#include <string>
#ifndef RELOJ_H
#define RELOJ_H

class Reloj{

  public:
  Reloj();
  Reloj(int _hora, int _minuto);

  int getHora();
  int getMinuto();
  
  void setHora(int _hora){hora = _hora;}
  void setMinuto(int _minuto) {minuto = _minuto;}
  void getReloj();

  private:
  int hora,minuto;

  
};

Reloj::Reloj()
{
  
}

Reloj::Reloj(int _hora, int _minuto)
{
  hora = _hora;
  minuto = _minuto;
  
}

int Reloj::getHora()
{
  return hora;
}

int Reloj::getMinuto()
{
  return minuto;
}

void Reloj::getReloj()
{
  if (0<= hora && hora < 10)
  {
    cout << "0" << hora << ":";

  }
  else 
  {
    cout << hora << ";";
  }
  if (0<= minuto && minuto <10)
  {
    cout << "0" << minuto;
  } 
  else {
  cout << minuto;
   }

}

#endif