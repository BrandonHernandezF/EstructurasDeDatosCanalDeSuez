#include <iostream>
#include <string>
#ifndef IDENTIFICADOR_H
#define IDENTIFICADOR_H

using namespace std;

class Identificador
{
  public:
  Identificador();
  Identificador(char mar, string id);

  char getMar();
  string getID();

  void setMar(char);
  void setID(string);


  void getDatos();

  private:

  char mar;
  string id;
  
};

Identificador::Identificador()
{
  
}

Identificador::Identificador(char _mar, string _id)
{
  mar = _mar;
  id = _id;  
}

char Identificador::getMar()
{
  return mar;
}

string Identificador::getID()
{
  return id;
}

void Identificador::setMar(char _mar)
{
  mar = _mar;
}

void Identificador::setID(string _id)
{
  id = _id;
}

void Identificador::getDatos()
{
  cout << mar << " " << id << endl;
}

#endif