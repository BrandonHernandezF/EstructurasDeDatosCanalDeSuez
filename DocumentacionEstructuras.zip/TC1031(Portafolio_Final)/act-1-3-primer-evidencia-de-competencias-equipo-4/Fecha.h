#include <iostream>
#include <string>
#ifndef FECHA_H
#define FECHA_H

using namespace std;

class Fecha
{
  public:
  Fecha();
  Fecha(int dia, int mes, int year);

  int getDia();
  int getMes();
  int getYear();
  void getFecha();

  void setDia(int d) {dia = d;}
  void setMes(int m) {mes = m;}
  void setYear(int y) {year = y;}

  private:

  int dia, mes, year;
 

};

Fecha::Fecha()
{
  
}

Fecha::Fecha(int _dia, int _mes, int _year)
{
  dia = _dia;
  mes = _mes;
  year = _year;
  
}


int Fecha::getDia()
{
  return dia;
}

int Fecha::getMes()
{
  return mes;
}

int Fecha::getYear()
{
  return year;
}

void Fecha::getFecha()
{
  if (0<= dia && dia <10)
  {
    cout << "0" << dia;
  }
  else
    {
        cout << dia;
    }

    if (0<=mes && mes <10)
    {
        cout << "-" << "0" << mes;
    }
    else 
    {
        cout << "-" << mes;
    }
    cout << "-" << year;
}

#endif