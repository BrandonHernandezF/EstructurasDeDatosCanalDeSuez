#ifndef UGRAPH_H
#define UGRAPH_H

#include <vector>
#include <queue>
using namespace std;

template <class VertexType>
class UnweightedDiGraph
{

public:
    UnweightedDiGraph();
    void addVertex(VertexType);
    void removeVertex(VertexType);
    void addEdge(VertexType, VertexType);
    void removeEdge(VertexType, VertexType);
    void MNPNew(vector<VertexType> &visited, VertexType vertice, int MNP);

    int getIndex(VertexType) const;
    void printVertices();
    void getAdjacents(VertexType, queue<VertexType> &);
    vector<VertexType> getVertices() const;
    VertexType getVertex(int) const;
    vector<VertexType> getEdges(VertexType) const;
    int getSize();
    void DFS(int index, vector<bool> &visited, stack<VertexType> &answer);
    int MNPrint(int index, vector<bool> &visited, stack<VertexType> &answer, int MNP);
    void BFS(VertexType Vertex, int MNP);

protected:
    vector<VertexType> verticesList;
    int size=0;
    vector<vector<int>> edges;
    
};

// =================================================================
// Constructor. Initializes the data of the graph.
//
// @param val, stored data in the node.
// =================================================================
template <class VertexType>
UnweightedDiGraph<VertexType>::UnweightedDiGraph()
{
  this->verticesList.resize(30);
  this->edges.resize(30);
  for (int i=0; i<30; i++)
  {
    this->edges[i].resize(30, false);
    //this->edges[i][i] = true;
  }
}

// =================================================================
// addVertex. Adds a new vertex to the graph.
// Complexity: O(1)
// @param vertex, vertex to be added.
// =================================================================
template <class VertexType>
void UnweightedDiGraph<VertexType>::addVertex(VertexType vertex)
{
    verticesList[size++] = vertex;
}

// =================================================================
// addEdge. Adds an edge between two edges to the graph.
// Complexity: O(1)
// @param fromVertex, vertex pointing towards.
// @param toVertex, vertex being pointed to.
// =================================================================
template <class VertexType>
void UnweightedDiGraph<VertexType>::addEdge(VertexType fromVertex, VertexType toVertex)
{
  int row = getIndex(fromVertex);
  int col = getIndex(toVertex);

  edges[row][col] = 1;
  edges[col][row] = 1;
 
}

// =================================================================
// getIndex. Get the index of a vertex in the list of vertices.
// Complexity: O(n)
// @param vertex, vertex to be looked for.
// =================================================================
template <class VertexType>
int UnweightedDiGraph<VertexType>::getIndex(VertexType vertex) const
{
  for (int i=0; i<size;i++)
  {
    if (verticesList[i] == vertex)
    {
      return i;
    }
  }

  return -1;

}


// =================================================================
// getAdjacents. Get adjacent vertices from a given vertex.
// Complexity: O(n)
// @param vertex, vertex to search adjacent vertices.
// @param adjacents, empty queue to be filled with adjacent vertices.
// =================================================================

template <class VertexType>
void UnweightedDiGraph<VertexType>::printVertices()
{
  for (int i = 0; i<size;i++)
  {

      cout << verticesList[i] << " -> " << endl;

  }
}

template <class VertexType>
void UnweightedDiGraph<VertexType>::getAdjacents(VertexType vertex, queue<VertexType> &adjacents)
{
   int fromVertex = getIndex(vertex);

  for (int toVertex = 0; toVertex < size; toVertex++)
  {
    if (edges[fromVertex][toVertex]>0 && toVertex != fromVertex)
    {
      adjacents.push(verticesList[toVertex]);
    }
  }
}

// =================================================================
// getVertices. Get the vertices of th graph.
// Complexity: O(1)
// =================================================================
template <class VertexType>
vector<VertexType> UnweightedDiGraph<VertexType>::getVertices() const
{
  return verticesList;  
}

// =================================================================
// getVertices. Get the vertices of th graph.
// Complexity: O(1)
// =================================================================
template <class VertexType>
VertexType UnweightedDiGraph<VertexType>::getVertex(int index) const
{
    return verticesList[index];
}

// =================================================================
// getSize. Get the vertices of the graph.
// Complexity: O(1)
// =================================================================
template <class VertexType>
int UnweightedDiGraph<VertexType>::getSize()
{
    return size;
}

template <class VertexType>
void UnweightedDiGraph<VertexType>::DFS(int index, vector<bool> &visited, stack<VertexType> &answer)
{
  queue<VertexType> adjacents;

  VertexType neighbour;

  visited[index] = true; //se marca como visitado

  getAdjacents(verticesList[index], adjacents);

  while(!adjacents.empty() ) //se revisan adyacentes
  {
    neighbour = adjacents.front(); //obtenemos un adjacente
    adjacents.pop(); // Quitamos del queue de vertices a revisar

    int indexNeighbour = getIndex(neighbour);

    if (!visited[indexNeighbour]) //si no se ha visitado antes ese vértice
    { 
      
      DFS(indexNeighbour, visited, answer); // Hacemos DFS
    }
  }  
  answer.push(verticesList[index]);
}

template <class VertexType>
int UnweightedDiGraph<VertexType>::MNPrint(int index, vector<bool> &visited, stack<VertexType> &answer, int MNP)
{
  queue<VertexType> adjacents;
  int contador = 0;
  int flag = 0;
  vector <VertexType> visitados;

  if (MNP == 1)
  {
    getAdjacents(verticesList[index], adjacents);
    while (!adjacents.empty())
      {
        cout << adjacents.front() << endl;
        answer.push(adjacents.front());
        contador++;
        adjacents.pop();
      }
  }
  else{

  getAdjacents(verticesList[index], adjacents);
  visitados.push_back(verticesList[index]);
  

  for(int k=0; k<adjacents.size()+1; k++)
  {
    visitados.push_back(adjacents.front());
    adjacents.pop();
  }

  getAdjacents(verticesList[index], adjacents);
  /*for (int i=0; i<visitados.size();i++)
  {
    cout << visitados[i] << endl;
  }*/
  
  
  int size1=adjacents.size();
  for (int j=0; j<size1; j++)
  {
    getAdjacents(adjacents.front(), adjacents);
    cout << adjacents.front() << endl;
    adjacents.pop();
  }

  for (int r=0; r<adjacents.size()+1;r++)
  {
    VertexType example = adjacents.front();
    adjacents.pop();
    for (int w=0; w<visitados.size(); w++)
    {
      if (example == visitados[w])
      {
        break;
      }
      else if (w+1 == visitados.size())
      {
        cout << example << endl;
      }
      
    }



    }
  }
  /*do
  {
    sizes = adjacents.size();
    
    for(int i=0; i<sizes; i++)
    {
      if (alerta==0)
      {
        cout << adjacents.front() << endl;
        contador++;
        alerta = 1;
        answer.push(adjacents.front());
        getAdjacents(adjacents.front(), adjacents);
        adjacents.pop();
      }
      else{
      for (int k=0; k<visitados.size();k++)
      {

        cout << "//// " << visitados[k] << endl;
        if (visitados[k] == adjacents.front())
        {
          alerta2 = 1;
        }
      }
      for (int k=0; k<visitados.size();k++)
      {
      if (alerta2 != 1)
      {
        cout << adjacents.front() << endl;
        contador++;
        answer.push(adjacents.front());
        visitados.push_back(adjacents.front());
        getAdjacents(adjacents.front(), adjacents);
        adjacents.pop();
      }
      }
      
      }
      }
    
    MNP--;
  } while (MNP != 0);
  }*/
  return contador;
}


/*template <class VertexType, class EdgeType>
void DiGraphType<VertexType, EdgeType>::DFS(VertexType vertex, vector<bool> &visited, stack<VertexType> &sort)
{
    queue<VertexType> adjacents;
    VertexType neighbour;
    int index = getIndex(vertex);
    visited[index] = true;
    getAdjacents(vertices[index], adjacents);

    while (!adjacents.empty()){
        neighbour = adjacents.front();
        adjacents.pop();

        int indexNeighbour = getIndex(neighbour);

        if (!visited[indexNeighbour]){
            DFS(vertices[indexNeighbour], visited, sort);
        }
    }
    sort.push(vertices[index]);
}*/

template <class VertexType>
void UnweightedDiGraph<VertexType>::MNPNew(vector<VertexType> &visited, VertexType vertice, int MNP)
{
  if (MNP != 0)
  {
  queue<VertexType> adyacentes;

  for (int w=0; w<visited.size(); w++)
    {
      if (vertice == visited[w])
      {
        break;
      }
      else if (w+1 == visited.size())
      {
        visited.push_back(vertice);
      }
      
    }

  getAdjacents(vertice, adyacentes);
  while(!adyacentes.empty())
  {
    visited.push_back(adyacentes.front());
    adyacentes.pop();
  }
  getAdjacents(vertice, adyacentes);

  for(int i=0; i<adyacentes.size()+1;i++)
  {
    VertexType example1 = adyacentes.front();
    adyacentes.pop();
    MNPNew(visited, example1, MNP - 1);
  }
  }
}

template <class VertexType>
void UnweightedDiGraph<VertexType>::BFS(VertexType Vertice, int MNP)
{
    queue<VertexType> search;
    queue<VertexType> adyacentes;
    vector<bool> visited(size,false);
    bool found = false;

    VertexType vertex;
    VertexType neighbour;
    int index = 0;
    int contador = 0;
    int Nivel = MNP;

    search.push(Vertice);

    while (!search.empty() && Nivel >= 0)
    {
        while (!search.empty())
        {
            vertex = search.front();
            search.pop();
            index = getIndex(vertex);
            visited[index] = true;
            contador++;
            getAdjacents(vertex, adyacentes);
            
        }
        
        while(!adyacentes.empty())
        {
            vertex = adyacentes.front();
            adyacentes.pop();
            index = getIndex(vertex);
            
            if(!visited[index])
            {
                search.push(vertex);
            }
        }
        
    Nivel = Nivel - 1;
    }
    contador = 0;
    for(int i = 0; i < visited.size(); i++)
    {
        if(!visited[i])
            contador++;
    }
    cout << contador << " ports not reachable from port " << Vertice << " with MNP = " << MNP << "." << endl;
}
#endif /* UGRAPH_H */