#include <string>
#include <iostream>
#include <vector>
#include <stack>

using namespace std;

#include "UnweightedDiGraph.h"

int main() {
  UnweightedDiGraph<string> Barcos;
  string Vertice1, Vertice2;
  int NumBarcos=0;
  cin >> NumBarcos;

  while (NumBarcos != 0)
  {
    cin >> Vertice1 >> Vertice2;
    
    if (Barcos.getIndex(Vertice1) == -1)
    {
      Barcos.addVertex(Vertice1);
    }

    if (Barcos.getIndex(Vertice2) == -1)
    {
      Barcos.addVertex(Vertice2);
    }

    Barcos.addEdge(Vertice1, Vertice2);

    NumBarcos--;
  }
  
  //Barcos.printVertices();

  int casos;
  cin >> casos;
  int MNP;
  
  vector<string> visited(100);
  int index;
  stack<string> answer;
  int contador = 0;
  int contcases = 0;
  vector<string> visitados;
  vector<string> NoRep;

  while(casos!=0)
  {
    cin >> Vertice1 >> MNP;
    contcases++;
    /*queue<string> adjacents2;
    index = Barcos.getIndex(Vertice1);
    cout << index;
    Barcos.MNPNew(visitados, Vertice1, MNP);
    for (int i=0; i<visitados.size(); i++)
    {
      cout << visitados[i] << endl;
      for (int k=0; k<NoRep.size();k++)
      {
      if (i==0)
      {
        NoRep.push_back(visitados[i]);
      }  
      else if (visitados[i] == NoRep[k])
      {
        break;
      }
      else if (k+1 == NoRep.size())
      {
        NoRep.push_back(visitados[i]);
      }
      }
    }

    for (int i=0; i<NoRep.size(); i++)
    {
      cout << "///" << NoRep.front() << endl;
      NoRep.pop_back();
    }
    contador = Barcos.MNPrint(index, visited, answer, MNP);
    cout << "Case " << contcases << ": " <<  Barcos.getSize() - contador - 1 <<  " ports not reachable from port " <<  Vertice1 << " with MNP = " << MNP << endl;*/
    
		cout << "Case " << contcases << ": ";
		Barcos.BFS(Vertice1, MNP);
    casos--;
    //cout << Barcos.getSize() << contador << endl;
  }

  


  
  
    
}