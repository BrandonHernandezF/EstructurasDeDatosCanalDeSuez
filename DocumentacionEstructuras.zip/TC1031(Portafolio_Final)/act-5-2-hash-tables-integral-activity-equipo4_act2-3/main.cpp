// =================================================================
//
// File: main.cpp
// Author: Brandon Alan Hernández Flores
// Date: 26/11/2021
//
// =================================================================
#include <iostream>

using namespace std;

int main()
{
	int m, n=0;
	vector<
	cin >> m >> n; 
	while (m!=0)
	{
		
		m--;
	}
	return 0;
}
